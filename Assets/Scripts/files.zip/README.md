# Chill Tap Buddy

A calm desk buddy Unity 2D application that reacts to clicks, runs a Pomodoro focus timer, and rewards points when focus sessions complete.

## Overview

Chill Tap Buddy is a low-distraction productivity companion designed to help you focus. The primary reward comes from completing focus sessions, while occasional taps on your buddy provide minor bonuses with built-in throttling to keep you on task.

## Features

- **Pomodoro Focus Timer**: 25-minute focus sessions (60-second demo mode available)
- **Interactive Buddy**: Tap your buddy for small point bonuses (throttled to 1 per minute)
- **Streak System**: Consecutive session completions multiply your rewards
- **Unlock System**: Earn points to unlock cosmetic items
- **Persistent Progress**: All data saved locally via PlayerPrefs

## Project Structure

```
Assets/
├── Scripts/
│   ├── Core/
│   │   ├── GameManager.cs          # Main game orchestration
│   │   ├── SaveService.cs          # JSON persistence via PlayerPrefs
│   │   └── RewardSystem.cs         # Point calculation and unlocks
│   ├── Timer/
│   │   └── FocusTimer.cs           # Pomodoro countdown logic
│   ├── Buddy/
│   │   ├── BuddyController.cs      # Click detection and animations
│   │   └── InputTracker.cs         # Optional keyboard activity sampling
│   └── UI/
│       └── UIController.cs         # UI updates and toast messages
├── ScriptableObjects/
│   └── UnlockDefinition.cs         # Unlock item data template
├── Animations/
│   ├── Buddy.controller            # Animator controller
│   └── BuddyIdle.anim              # Animation clips
├── Prefabs/
│   └── Buddy.prefab
├── Sprites/
│   └── (placeholder sprites)
└── Scenes/
    └── Main.unity
```

## Requirements

- Unity 2022.3 LTS (recommended)
- Windows/Mac/Linux build target

## Quick Start

### 1. Create New Project
1. Open Unity Hub
2. Create new 2D project named "ChillTapBuddy"
3. Select Unity 2022.3 LTS

### 2. Import Scripts
Copy all `.cs` files from `Scripts/` into your `Assets/Scripts/` folder.

### 3. Scene Setup

#### Create Managers
1. Create empty GameObject named `[Managers]`
2. Add child `GameManager` with `GameManager.cs`
3. Add child `SaveService` with `SaveService.cs`
4. Add child `RewardSystem` with `RewardSystem.cs`

#### Create Buddy
1. Create empty GameObject named `[World]`
2. Add child `Buddy` with:
   - SpriteRenderer (assign placeholder sprite)
   - Animator (create controller, see Animation Setup)
   - BoxCollider2D (set to size of sprite)
   - BuddyController.cs
   - InputTracker.cs (optional)

#### Create UI Canvas
1. Right-click Hierarchy → UI → Canvas
2. Rename to `[UI]`
3. Add UIController.cs to Canvas
4. Create UI elements (see detailed setup below)

### 4. Test
1. Press Play
2. Click "Start Focus" button
3. Timer counts down (60 sec in demo mode)
4. Tap buddy for bonus points
5. Complete session to earn rewards

## Demo Mode

For quick testing, the timer defaults to 60 seconds in the Unity Editor. Set `demoMode = false` in FocusTimer.cs for full 25-minute sessions.

## Build Instructions

1. File → Build Settings
2. Select "PC, Mac & Linux Standalone"
3. Click "Build"
4. Choose output folder
5. Run the executable

## Data Persistence

All progress is saved to PlayerPrefs as JSON:
- Total points earned
- Current streak count
- Unlocked item IDs
- Equipped skin and background

To reset progress, call `SaveService.Instance.ClearSave()` or delete PlayerPrefs.

## License

MIT License - Free for personal and commercial use.

## Credits

Developed as a productivity tool prototype. Uses placeholder assets - replace with your own artwork for production.
