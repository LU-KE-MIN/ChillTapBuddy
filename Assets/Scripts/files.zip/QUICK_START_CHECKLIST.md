# Quick Start Checklist

Use this checklist to rapidly set up Chill Tap Buddy in Unity.

## Phase 1: Project Setup (10 minutes)

- [ ] Create new Unity 2D project (2022.3 LTS)
- [ ] Create folder structure: Scripts/, Scripts/Core/, Scripts/Timer/, Scripts/Buddy/, Scripts/UI/
- [ ] Create additional folders: ScriptableObjects/, Sprites/, Animations/, Prefabs/, Scenes/
- [ ] Import all C# scripts to their respective folders
- [ ] Wait for compilation (check Console for errors)

## Phase 2: Animator Setup (5 minutes)

- [ ] Create Animator Controller in Animations/ folder named "BuddyAnimator"
- [ ] Open Animator window and add parameters:
  - [ ] Trigger: "Tap"
  - [ ] Bool: "IsFocusing"
- [ ] Create states: Idle, Tap
- [ ] Create transition Idle → Tap (condition: Tap trigger, no exit time)
- [ ] Create transition Tap → Idle (has exit time: 1.0)

## Phase 3: Scene Hierarchy (15 minutes)

### Managers
- [ ] Create empty "[Managers]" parent
- [ ] Create child "GameManager" + add GameManager.cs
- [ ] Create child "SaveService" + add SaveService.cs
- [ ] Create child "RewardSystem" + add RewardSystem.cs
- [ ] Create child "FocusTimer" + add FocusTimer.cs

### World
- [ ] Create empty "[World]" parent
- [ ] Create child "Buddy"
- [ ] Add to Buddy: SpriteRenderer (assign any sprite)
- [ ] Add to Buddy: Animator (assign BuddyAnimator)
- [ ] Add to Buddy: BoxCollider2D (resize to sprite)
- [ ] Add to Buddy: BuddyController.cs
- [ ] Add to Buddy: InputTracker.cs (optional)

### UI Canvas
- [ ] Create UI Canvas, rename to "[UI]"
- [ ] Verify EventSystem exists
- [ ] Add UIController.cs to Canvas

### Timer UI
- [ ] Create TimerPanel (Panel)
- [ ] Create TimerText (TMP Text) - "25:00", size 72
- [ ] Create TimerStatusText (TMP Text) - "Ready", size 24

### Buttons
- [ ] Create StartButton (Button) - "Start Focus"
- [ ] Create PauseButton (Button) - "Pause"
- [ ] Create StopButton (Button) - "Stop"

### Stats UI
- [ ] Create PointsText (TMP Text) - "0"
- [ ] Create StreakText (TMP Text) - "No streak"
- [ ] Create SessionTapsText (TMP Text) - "Taps: 0/5"

### Toast
- [ ] Create ToastPanel (Panel) - DISABLE IT
- [ ] Create ToastText (TMP Text) child

### Reward Popup
- [ ] Create RewardPopup (Panel) - DISABLE IT
- [ ] Create RewardTotalText (TMP Text) - "+100"
- [ ] Create RewardBreakdownText (TMP Text)
- [ ] Create RewardCloseButton (Button) - "Continue"

## Phase 4: Wire References (10 minutes)

### UIController (on Canvas)
- [ ] Assign TimerText
- [ ] Assign TimerStatusText
- [ ] Assign StartButton, PauseButton, StopButton
- [ ] Assign StartButtonText (the TMP Text inside StartButton)
- [ ] Assign PointsText, StreakText, SessionTapsText
- [ ] Assign ToastPanel, ToastText
- [ ] Assign RewardPopup, RewardTotalText, RewardBreakdownText, RewardCloseButton

### GameManager
- [ ] Assign FocusTimer reference
- [ ] Assign BuddyController reference
- [ ] Assign InputTracker reference (if used)
- [ ] Assign SaveService reference
- [ ] Assign RewardSystem reference
- [ ] Assign UIController reference

### BuddyController
- [ ] Assign Animator reference (auto-finds if on same object)

## Phase 5: Create Unlocks (5 minutes)

- [ ] Right-click ScriptableObjects/ → Create → ChillTapBuddy → Unlock Definition
- [ ] Create "HappySkin" (id: happy_skin, cost: 200)
- [ ] Create "NightBackground" (id: night_bg, cost: 350, type: Background)
- [ ] Create "PartyHat" (id: party_hat, cost: 500, type: Accessory)
- [ ] Select RewardSystem and add all 3 to Unlock Definitions list

## Phase 6: Test (5 minutes)

- [ ] Press Play
- [ ] Verify timer shows "01:00" (demo mode)
- [ ] Click Start Focus - timer counts down
- [ ] Click Buddy - animation plays, scale bumps
- [ ] Wait for completion - reward popup appears
- [ ] Check points/streak updated
- [ ] Stop and restart Play mode - data persists

## Phase 7: Build (5 minutes)

- [ ] File → Build Settings
- [ ] Add Main scene
- [ ] Select PC, Mac & Linux Standalone
- [ ] Configure Player Settings (name, icon)
- [ ] Build and test executable

## Common Issues

**Buddy clicks not working:**
- Check BoxCollider2D exists and sized correctly
- Ensure EventSystem in scene
- Verify Camera.main exists

**UI not updating:**
- Check all references assigned in UIController Inspector
- Look for null reference errors in Console

**Animations not playing:**
- Verify Animator Controller assigned
- Check parameter names match exactly (case-sensitive)

**Data not saving:**
- Check Console for JSON errors
- Verify SaveService exists in scene

## Debug Commands

Right-click GameManager in Inspector during Play mode:
- "Debug: Add 100 Points" - Instant points for testing unlocks
- "Debug: Clear Save Data" - Reset all progress
- "Debug: Complete Session Now" - Skip timer for testing rewards

---

Total setup time: approximately 45-60 minutes for first-time setup.
