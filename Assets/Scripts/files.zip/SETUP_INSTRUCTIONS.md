# Unity Editor Setup Instructions

This document provides step-by-step instructions for setting up the Chill Tap Buddy project in Unity 2022.3 LTS.

## Prerequisites

Before beginning, ensure you have Unity 2022.3 LTS installed via Unity Hub. The project uses the 2D template and requires TextMeshPro (included by default in Unity 2022).

## Step 1: Create the Project

Open Unity Hub and click "New Project". Select the 2D template, name the project "ChillTapBuddy", and create it in your preferred location. Once the project loads, Unity will prompt you to import TextMeshPro essentials if they are not already present; accept this prompt.

## Step 2: Import Scripts

Create the following folder structure in your Assets folder using the Project window: Assets/Scripts, Assets/Scripts/Core, Assets/Scripts/Timer, Assets/Scripts/Buddy, Assets/Scripts/UI, Assets/ScriptableObjects, Assets/Sprites, Assets/Animations, and Assets/Prefabs.

Copy the provided C# scripts into their respective folders according to the folder structure outlined in the README. Specifically, place GameManager.cs in Assets/Scripts, place SaveService.cs, RewardSystem.cs, and UnlockDefinition.cs in Assets/Scripts/Core, place FocusTimer.cs in Assets/Scripts/Timer, place BuddyController.cs and InputTracker.cs in Assets/Scripts/Buddy, and place UIController.cs in Assets/Scripts/UI.

Wait for Unity to compile all scripts before proceeding.

## Step 3: Create Placeholder Sprites

Create placeholder sprites for testing. In the Project window, right-click in Assets/Sprites and select Create → 2D → Sprites → Square. Rename it "BuddyPlaceholder". Create additional placeholder sprites named "UnlockPreview1", "UnlockPreview2", and "UnlockPreview3" for the unlock system.

Alternatively, import any PNG images you wish to use as placeholders.

## Step 4: Set Up the Animator Controller

Navigate to Assets/Animations in the Project window. Right-click and select Create → Animator Controller. Name it "BuddyAnimator".

Double-click the animator controller to open the Animator window. In the Parameters tab on the left side, add a new Trigger parameter named "Tap" and a new Bool parameter named "IsFocusing".

Right-click in the Animator canvas and create a new state named "Idle". This will be the default state (indicated by orange color). Create a second state named "Tap". Create an optional third state named "FocusIdle" if you want different idle behavior during focus sessions.

Create a transition from "Idle" to "Tap" by right-clicking on "Idle" and selecting "Make Transition", then clicking on "Tap". Select this transition and in the Inspector, uncheck "Has Exit Time", set Transition Duration to 0, and add a Condition with the parameter "Tap".

Create a transition from "Tap" back to "Idle". Select this transition, check "Has Exit Time", and set Exit Time to 1.0 so the tap animation plays fully before returning to idle.

Optionally, create transitions between "Idle" and "FocusIdle" using the "IsFocusing" bool parameter.

## Step 5: Create the Scene Hierarchy

Open the Main scene (or create a new scene and save it as "Main" in Assets/Scenes). Build the hierarchy as follows.

### Managers Group

Create an empty GameObject and name it "[Managers]". This serves as an organizational parent. Create a child GameObject under [Managers] named "GameManager". Add the GameManager script component to it.

Create another child under [Managers] named "SaveService" and add the SaveService script. Create another child named "RewardSystem" and add the RewardSystem script. Create a final child named "FocusTimer" and add the FocusTimer script.

### World Group

Create an empty GameObject named "[World]". Create a child GameObject named "Buddy". On the Buddy object, add a SpriteRenderer component and assign your BuddyPlaceholder sprite. Add an Animator component and assign the BuddyAnimator controller you created. Add a BoxCollider2D component and adjust its size to match the sprite (click "Edit Collider" to resize visually). Add the BuddyController script. Optionally add the InputTracker script to the same object.

Set the Buddy's Transform position to (0, -1, 0) so it appears in the lower portion of the screen.

### UI Canvas

Right-click in the Hierarchy and select UI → Canvas. Rename it "[UI]". The Canvas will automatically include an EventSystem; if it does not, create one via UI → Event System.

Select the Canvas and set its Canvas Scaler component to "Scale With Screen Size" with a Reference Resolution of 1920×1080.

#### Timer Panel

Create a child Panel under [UI] named "TimerPanel". Position it at the top center of the canvas. Create a TMP Text child named "TimerText" with default text "25:00" and font size 72. Create another TMP Text child named "TimerStatusText" with default text "Ready" and font size 24. Optionally create an Image child named "TimerProgressFill" with Image Type set to Filled for a circular or horizontal progress indicator.

#### Control Buttons

Create a horizontal layout group or manually position three buttons. Create a Button named "StartButton" with child TMP Text displaying "Start Focus". Create a Button named "PauseButton" with child TMP Text displaying "Pause". Create a Button named "StopButton" with child TMP Text displaying "Stop".

#### Stats Panel

Create a Panel named "StatsPanel" positioned below the timer or in a sidebar. Create TMP Text children named "PointsText" (default "0"), "StreakText" (default "No streak"), and "SessionTapsText" (default "Taps: 0/5").

#### Unlock List Panel

Create a Panel named "UnlockListPanel" positioned on the side of the canvas. Create an empty child named "UnlockListContainer" that will hold dynamically instantiated unlock items. Set up a Vertical Layout Group on this container.

#### Unlock Item Prefab

Create a new Panel in the scene that will serve as the unlock item template. Add an Image for the preview, TMP Text for the item name, TMP Text for the cost, a Button for purchasing, and optional GameObjects for locked overlay and unlocked checkmark. Add the UnlockItemUI script to this panel.

Assign all the UI element references in the Inspector. Drag this panel into Assets/Prefabs to create a prefab, then delete the instance from the scene.

#### Toast Panel

Create a Panel named "ToastPanel" positioned at the bottom center. Add a TMP Text child named "ToastText". Disable the ToastPanel GameObject (uncheck the checkbox at the top of the Inspector) so it starts hidden.

#### Reward Popup

Create a Panel named "RewardPopup" covering most of the screen with a semi-transparent background. Add TMP Text children for "RewardTotalText" (displays "+100"), "RewardBreakdownText" (displays the breakdown), and a Button named "RewardCloseButton" with text "Continue". Disable this panel so it starts hidden.

### Wire Up the UIController

Select the [UI] Canvas and add the UIController script. In the Inspector, drag and assign all the UI element references: TimerText, TimerStatusText, TimerProgressFill, StartButton, PauseButton, StopButton, StartButtonText, PointsText, StreakText, SessionTapsText, UnlockListContainer, UnlockItemPrefab, ToastPanel, ToastText, RewardPopup, RewardTotalText, RewardBreakdownText, and RewardCloseButton.

### Wire Up the GameManager

Select the GameManager object. In the Inspector, assign references to the FocusTimer, BuddyController, InputTracker (if used), SaveService, RewardSystem, and UIController. If you have audio clips for tap sounds, session completion, and unlocks, assign those as well and add an AudioSource component to the GameManager.

## Step 6: Create Unlock Definitions

In Assets/ScriptableObjects, right-click and select Create → ChillTapBuddy → Unlock Definition. Create three unlock definitions.

Name the first one "HappySkin". Set ID to "happy_skin", Display Name to "Happy Buddy", Cost to 200 points, and assign a preview sprite.

Name the second one "NightBackground". Set ID to "night_bg", Display Name to "Night Mode", Cost to 350 points, and assign a preview sprite. Set Unlock Type to Background.

Name the third one "PartyHat". Set ID to "party_hat", Display Name to "Party Hat", Cost to 500 points, and assign a preview sprite. Set Unlock Type to Accessory.

Select the RewardSystem object and in the Inspector, add these three UnlockDefinition assets to the Unlock Definitions list.

## Step 7: Configure the FocusTimer

Select the FocusTimer object. In the Inspector, you will see options for Focus Duration Seconds (default 1500 for 25 minutes), Demo Mode (checked for 60-second sessions during testing), and Demo Duration Seconds (default 60). Leave Demo Mode checked for initial testing.

## Step 8: Test the Setup

Enter Play mode by pressing the Play button. Verify the following: the timer displays "01:00" (in demo mode), clicking Start Focus begins the countdown, clicking the Buddy triggers the tap animation and scale bump, bonus taps are awarded no more than once per minute, the session completes after 60 seconds and shows the reward popup, and points and streak are saved between play sessions.

## Step 9: Build for Windows

Open File → Build Settings. Click "Add Open Scenes" to add the Main scene. Select "PC, Mac & Linux Standalone" as the platform. Click "Player Settings" and configure: Product Name as "Chill Tap Buddy", Company Name as your preference, and Default Icon using your icon sprite.

Click "Build" and choose an output folder. Run the generated executable to test the build.

## Recording a Demo GIF/Video

Use Windows Game Bar (Win+G) or OBS Studio to record gameplay. Demonstrate starting a focus session, tapping the buddy, and completing a session. Tools like ScreenToGif can capture directly to GIF format.

## Troubleshooting

If clicks on the Buddy are not detected, ensure the BoxCollider2D is properly sized and the Buddy is on a layer that receives raycasts. Verify that an EventSystem exists in the scene.

If UI buttons are not responding, check that the Canvas has a GraphicRaycaster component and that all buttons have interactable set to true.

If animations are not playing, verify the Animator Controller is assigned to the Buddy's Animator component and that the parameter names match exactly (case-sensitive).

If data is not persisting, check the console for JSON parse errors and verify PlayerPrefs are being saved correctly.
